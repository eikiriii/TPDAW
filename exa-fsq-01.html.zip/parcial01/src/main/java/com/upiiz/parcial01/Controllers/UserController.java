package com.upiiz.parcial01.Controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class UserController {
    @GetMapping("/Usuarios/agregar") 
    public String UsuariosAgregar() {
        return "/Usuarios/agregar";
    }
    @GetMapping("/Usuarios/editar")
    public String Usuariosditar() {
        return "/Usuarios/editar";
    }
    @GetMapping("/Usuarios/eliminar")
    public String UsuariosEliminar() {
        return "/Usuarios/eliminar";
    }
    @GetMapping("/Usuarios")
    public String Usuarios() {
        return "/Usuarios/usuarios";
    }
}
