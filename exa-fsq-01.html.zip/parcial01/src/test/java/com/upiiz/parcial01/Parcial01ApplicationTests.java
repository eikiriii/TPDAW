package com.upiiz.parcial01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Parcial01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
