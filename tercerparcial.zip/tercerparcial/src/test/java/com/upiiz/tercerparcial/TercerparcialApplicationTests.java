package com.upiiz.tercerparcial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TercerparcialApplicationTests {

	@Test
	void contextLoads() {
	}

}
