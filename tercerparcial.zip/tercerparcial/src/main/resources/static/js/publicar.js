$(document).ready(function() {
    // Inicializa DataTable solo una vez
    $('#example').DataTable();
});
$(document).ready(function() {
    obtenerPublicaciones();
});

$(document).ready(function() {
    publicacionestable();
});

function obtenerPublicaciones() { 
     $.ajax({
        method:"GET",
        url: "/v1/api/publicaciones",
        data: {},
        success: function( resultado ) {
            if(resultado.estado===1){
                let contenedor = $('#contenedorPublicaciones');
                contenedor.empty();
                let publicaciones = resultado.publicaciones;
                publicaciones.forEach(publicacion => {
                    let tarjeta = `
                        <div class="card mb-3">
                            <div class="card-body">
                                <h5 class="card-title">${publicacion.titulo}</h5>
                                <p class="card-text">${publicacion.contenido}</p>
                                <p class="card-text"><small class="text-muted">Publicado el: ${publicacion.fecha_publicacion || ''}</small></p>
                                <button class="btn btn-primary btn-sm me-2" data-bs-toggle="modal" data-bs-target="#BorrarModal" onclick="seleccionarPublicacionEliminar(${publicacion.id})">
                                    <i class="fa fa-trash"></i> Eliminar
                                </button>
                                <button class="btn btn-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#EditarModal" onclick="seleccionarPublicacionEditar(${publicacion.id})">
                                    <i class="fa fa-edit"></i> Editar
                                </button>
                            </div>
                        </div>
                    `;
                    contenedor.append(tarjeta);

                });
            }
        },
        error:function (xhr,error,mensaje){

        }
    });
}

function guardarPublicacion(){
    ahora = new Date();
    titulo_publicacion = document.getElementById("titulo").value;
    contenido_publicacion = document.getElementById("contenido").value;
    fecha_publicacion = ahora.toISOString().slice(0,10); // "YYYY-MM-DD"
    
    //Validar de forma simple los campos - EXPRESIONES REGULARES
    if(titulo_publicacion && contenido_publicacion && fecha_publicacion){
    $.ajax({
            url: "/v1/api/publicaciones",
            contentType:"application/json",
            method:"POST",
            data: JSON.stringify({
                titulo:titulo_publicacion,
                contenido:contenido_publicacion,
                fecha_publicacion:fecha_publicacion
            }),
            success: function( resultado ) {
                if(resultado.estado===1){
                obtenerPublicaciones(); 
        $('#postModal').hide();
        let modal = bootstrap.Modal.getOrCreateInstance(document.getElementById('postModal'));
        modal.hide();

            }else{
                //Todo mal
                alert(resultado.mensaje);
            }
        },
        error:function (xhr,error,mensaje) {
            //Se dispara la funcion si no conexion al servidor
                alert("Error de comunicacion: "+xhr.responseText);
            }
        });
        $('#basicModal').hide()
        let modal = bootstrap.Modal.getOrCreateInstance(document.getElementById('basicModal'));
        modal.hide();
        }else{
        alert("Ingresa los datos correctamente");
    }
}

function seleccionarPublicacionEditar(id) {
    idPublicacionActualizar=id;
    $.ajax({
        method:"GET",
        url: "/v1/api/publicaciones/actualizar/"+idPublicacionActualizar,
        data: {},
        success: function( resultado ) {
            if(resultado.estado===1){
                let publicacion = resultado.publicacion;
                $('#EditarTitulo').val(publicacion.titulo);
                $('#EditarContenido').val(publicacion.contenido);
                $('#EditarFecha').val(publicacion.fecha_publicacion);
            }else{
                alert(resultado.mensaje);
            }
        },
        error:function (xhr,error, mensaje) {
            alert(xhr.responseText);
        }
    });
}

function editarPublicacion() {
    ahora = new Date();
    titulo_publicacion=$('#EditarTitulo').val();
    contenido_publicacion=$('#EditarContenido').val();
    fecha_publicacion= ahora.toISOString().slice(0,10); // "YYYY-MM-DD"
    if(titulo_publicacion && contenido_publicacion && fecha_publicacion){
        $.ajax({
            url: "/v1/api/publicaciones/actualizar/"+idPublicacionActualizar,
            contentType:"application/json",
            method:"POST",
            data: JSON.stringify({
                id:idPublicacionActualizar,
                titulo:titulo_publicacion,
                contenido:contenido_publicacion,
                fecha_publicacion:fecha_publicacion
            }),
            success: function( resultado ) {
                if(resultado.estado==1){
                    obtenerPublicaciones(); // Refresca la lista
                    let modalActualizar = bootstrap.Modal.getOrCreateInstance(document.getElementById('basicModal2'));
                    modalActualizar.hide();
                }else{
                    //Todo mal
                    alert(resultado.mensaje);
                }
            },
            error:function (xhr,error,mensaje) {
                //Se dispara la funcion si no conexion al servidor
                alert("Error de comunicacion: "+error);
            }
        });
        let modalActualizar = bootstrap.Modal.getOrCreateInstance(document.getElementById('EditarModal'));
        modalActualizar.hide();
    }else{
        alert("Ingresa los datos correctamente")
    }

}

function seleccionarPublicacionEliminar(id) {
    idPublicacionEliminar=id;
}

function eliminarPublicacion() {
    $.ajax({
        method: "POST",
        url: "/v1/api/publicacion/eliminar",
        contentType:"application/json",
        data:JSON.stringify({
            id:idPublicacionEliminar,
        }),
        success: function( resultado ) {
            if(resultado.estado===1){
                obtenerPublicaciones(); // Refresca la lista
                let modalActualizar = bootstrap.Modal.getOrCreateInstance(document.getElementById('BorrarModal'));
                modalActualizar.hide();
            }else{
                alert(resultado.mensaje)
            }
        },
        error:function (xhr,error,mensaje){
            alert("Error de comunicacion "+error)
        }
    });

}



function publicacionestable() {
    $.ajax({
        method: "GET",
        url: "/v1/api/publicaciones",
        success: function(resultado) {
            if (resultado.estado === 1) {
                let tabla = $('#example').DataTable();
                tabla.clear();
                let publicaciones = resultado.publicaciones;
                publicaciones.forEach(publicacion => {
                    let botones = `
                        <button class="btn btn-primary btn-sm me-2" data-bs-toggle="modal" data-bs-target="#BorrarModal" onclick="seleccionarPublicacionEliminar(${publicacion.id})">
                            <i class="fa fa-trash"></i> Eliminar
                        </button>
                        <button class="btn btn-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#EditarModal" onclick="seleccionarPublicacionEditar(${publicacion.id})">
                            <i class="fa fa-edit"></i> Editar
                        </button>
                    `;
                    tabla.row.add([
                        publicacion.id,
                        publicacion.titulo,
                        publicacion.contenido,
                        publicacion.fecha_publicacion,
                        botones
                    ]).node().id='renglon_'+publicacion.id;
                });
                tabla.draw();
            }
        },
        error: function(xhr, error, mensaje) {
            alert("Error al cargar publicaciones");
        }
    });
}

