package com.upiiz.tercerparcial.Services;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Service;

import com.upiiz.tercerparcial.Models.PublicacionesModel;
import com.upiiz.tercerparcial.Repositories.PublicacionesRepository;

@Service
public class PublicacionesService implements PublicacionesRepository {
    @Autowired
    JdbcTemplate jdbcTemplate;

    @Override
    public List<PublicacionesModel> findAllPublicaciones() {
        return jdbcTemplate.query("SELECT * FROM publicaciones",
                new BeanPropertyRowMapper<>(PublicacionesModel.class));
    }

    @Override
    public PublicacionesModel findPublicacionById(int id) {
        return jdbcTemplate.query("SELECT * FROM publicaciones WHERE id=?",
                        new BeanPropertyRowMapper<>(PublicacionesModel.class),id)
                .stream().findFirst().orElse(new PublicacionesModel());
    }

    @Override
    public PublicacionesModel save(PublicacionesModel publicacion) {
        KeyHolder keyHolder = new GeneratedKeyHolder(); // Para capturar el ID generado

        jdbcTemplate.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(
                    "INSERT INTO publicaciones(titulo, contenido, fecha_publicacion) VALUES (?, ?, ?)",
                    Statement.RETURN_GENERATED_KEYS // Indicar que queremos recuperar las claves generadas
            );
            ps.setString(1, publicacion.getTitulo());
            ps.setString(2, publicacion.getContenido());
            ps.setDate(3, java.sql.Date.valueOf(publicacion.getFecha_publicacion()));
            return ps;
        }, keyHolder);

        // Obtenemos el ID generado y lo asignamos al producto
        Number generatedId = keyHolder.getKey();
        if (generatedId != null) {
            publicacion.setId(generatedId.intValue());
        }else {
            publicacion.setId(0);
        }

        return publicacion; // Retornamos el modelo con el ID asignado
    }

    @Override
    public int update(PublicacionesModel publicacion) {
        int registrosAfectados=jdbcTemplate.update(
                "UPDATE publicaciones SET titulo=?, contenido=?, fecha_publicacion=? WHERE id=?",
                publicacion.getTitulo(), publicacion.getContenido(), publicacion.getFecha_publicacion(), publicacion.getId());
        return registrosAfectados;
    }

    @Override
    public int delete(int id) {
        int registrosAfectados=jdbcTemplate.update("DELETE FROM publicaciones WHERE id=?",id);
        return registrosAfectados;
    }
}
