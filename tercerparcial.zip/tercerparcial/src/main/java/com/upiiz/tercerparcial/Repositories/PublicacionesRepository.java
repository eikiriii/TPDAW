package com.upiiz.tercerparcial.Repositories;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.upiiz.tercerparcial.Models.PublicacionesModel;

@Repository
public interface PublicacionesRepository {
    public List<PublicacionesModel> findAllPublicaciones();
    public PublicacionesModel findPublicacionById(int id);
    public PublicacionesModel save(PublicacionesModel model);
    public int update(PublicacionesModel model);
    public int delete(int id);

}
