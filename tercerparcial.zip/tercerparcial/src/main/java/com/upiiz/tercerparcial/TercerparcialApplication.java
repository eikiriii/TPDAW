package com.upiiz.tercerparcial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TercerparcialApplication {

	public static void main(String[] args) {
		SpringApplication.run(TercerparcialApplication.class, args);
	}

}
