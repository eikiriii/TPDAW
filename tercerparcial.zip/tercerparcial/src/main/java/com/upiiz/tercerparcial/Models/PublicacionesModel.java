package com.upiiz.tercerparcial.Models;

import java.time.LocalDate;

public class PublicacionesModel {

    private int id;
    private String titulo;
    private String contenido;
    private LocalDate fecha_publicacion;

    public PublicacionesModel() {
    }

    public PublicacionesModel(String titulo, String contenido, LocalDate fecha_publicacion) {
        this.titulo = titulo;
        this.contenido = contenido;
        this.fecha_publicacion = fecha_publicacion;
    }


    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getTitulo() {
        return titulo;
    }
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
    public String getContenido() {
        return contenido;
    }
    public void setContenido(String contenido) {
        this.contenido = contenido;
    }
    
    public LocalDate getFecha_publicacion() {
        return fecha_publicacion;
    }
    public void setFecha_publicacion(LocalDate fecha_publicacion) {
        this.fecha_publicacion = fecha_publicacion;
    }
    

}
