package com.upiiz.tercerparcial.Controllers;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.upiiz.tercerparcial.Models.PublicacionesModel;
import com.upiiz.tercerparcial.Services.PublicacionesService;

@Controller
public class PublicacionesController {

    @Autowired
    private PublicacionesService publicacionesService;

    @GetMapping("/")
    public String index() {
        return "publicaciones";
    }

    @GetMapping("publicaciones/datatable")
    public String publicaciones() {
        return "publicaciones-datatable";
    }

    @GetMapping("publicaciones/lista")
    public String publicacionesLista() {
        return "publicaciones-lista";
    }
    
    @GetMapping("/v1/api/publicaciones")
    public ResponseEntity<Map<String,Object>> getAllPublicaciones() {
        List<PublicacionesModel> publicaciones=publicacionesService.findAllPublicaciones();
        return ResponseEntity.ok(Map.of(
                "estado",1,
                "mensaje","Listado de publicaciones",
                "publicaciones",publicaciones
        ));
    }

    @PostMapping("/v1/api/publicaciones")
    public ResponseEntity<Map<String,Object>> publicacionesPost(@RequestBody Map<String,Object> objetoPublicacion) {
        PublicacionesModel publicacion = new PublicacionesModel(
                objetoPublicacion.get("titulo").toString(),
                objetoPublicacion.get("contenido").toString(),
                LocalDate.parse(objetoPublicacion.get("fecha_publicacion").toString())
        );
        //Esta Publicacion ya trae su id, que es util para el Front
        PublicacionesModel PublicacionGuardada = publicacionesService.save(publicacion);
        if(PublicacionGuardada!=null)
            return ResponseEntity.ok(Map.of(
                    "estado",1,
                    "mensaje","Publicacion guardada correctamente",
                    "Publicacion", PublicacionGuardada
            ));
        else
            return ResponseEntity.ok(Map.of(
                    "estado",0,
                    "mensaje","Error: No se pudo guardar la Publicacion",
                    "Publicacion", objetoPublicacion
            ));
    }

    @GetMapping("/v1/api/publicaciones/actualizar/{id}")
    public ResponseEntity<Map<String,Object>> publicacionActualizar(@PathVariable int id) {
        PublicacionesModel publicacion = publicacionesService.findPublicacionById(id);
        return ResponseEntity.ok(Map.of(
                "estado",1,
                "mensaje","Publicacion encontrada",
                "publicacion", publicacion
        ));
    }

    @PostMapping("/v1/api/publicaciones/actualizar/{id}")
    public ResponseEntity<Map<String,Object>> publicacionActualizarDatos(@PathVariable int id, @RequestBody Map<String,Object> objetoPublicacion) {
        PublicacionesModel publicacion = new PublicacionesModel(
                objetoPublicacion.get("titulo").toString(),
                objetoPublicacion.get("contenido").toString(),
                LocalDate.parse(objetoPublicacion.get("fecha_publicacion").toString())
        );
        publicacion.setId(id);
        if(publicacionesService.update(publicacion) > 0)
            return ResponseEntity.ok(Map.of(
                    "estado",1,
                    "mensaje","Publicacion actualizada correctamente",
                    "publicacion", publicacion
            ));
        else
            return ResponseEntity.ok(Map.of(
                    "estado",0,
                    "mensaje","Error: No se pudo actualizar la publicacion",
                    "publicacion", objetoPublicacion
            ));
    }

    @PostMapping("/v1/api/publicacion/eliminar")
    public ResponseEntity<Map<String,Object>> eliminarPublicacion(
            @RequestBody Map<String,Object> objetoPublicacion) {

        int id = Integer.parseInt(objetoPublicacion.get("id").toString());

        if(publicacionesService.delete(id) > 0){
            return ResponseEntity.ok(Map.of(
                    "estado",1,
                    "mensaje","Publicacion eliminada"
            ));
        }else {
            return ResponseEntity.ok(Map.of(
                    "estado",0,
                    "mensaje","No se pudo eliminar la publicacion"
            ));
        }
    }

}
