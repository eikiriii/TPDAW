package com.upiiz.chat.controllers;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.upiiz.chat.models.ChatModel;
import com.upiiz.chat.services.ChatService;

@Controller
public class HomeController {
    @Autowired ChatService chatService;

    @GetMapping
    public String home() {
        return "index"; // Retorna el nombre de la vista a renderizar
    }

    @GetMapping("/api/mensajes")
    public ResponseEntity<Map<String,Object>> getAllMensajes() {
        List<ChatModel> mensajes=chatService.findAllChats();
        return ResponseEntity.ok(Map.of(
                "estado",1,
                "mensaje","Listado de carreras",
                "carreras",mensajes
        ));
    }
    
    @PostMapping("/api/mensajes")
    public ResponseEntity<Map<String,Object>> carreraPost(@RequestBody Map<String,Object> objetoChat) {
        ChatModel carrera = new ChatModel(
                objetoChat.get("texto").toString()
        );
        //Esta Carrera ya trae su id, que es util para el Front
        ChatModel ChatGuardado = chatService.save(carrera);
        if(ChatGuardado!=null)
            return ResponseEntity.ok(Map.of(
                    "estado",1,
                    "mensaje","Carrera guardada correctamente",
                    "Carrera", ChatGuardado
            ));
        else
            return ResponseEntity.ok(Map.of(
                    "estado",0,
                    "mensaje","Error: No se pudo guardar la Carrera",
                    "Carrera", objetoChat
            ));
    }
}
