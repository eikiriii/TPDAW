package com.upiiz.chat.models;


public class ChatModel {
    private int id;
    private String mensaje;

    public ChatModel() {
        // Constructor por defecto
    }
    public ChatModel(String mensaje) {
        this.mensaje = mensaje;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getMensaje() {
        return mensaje;
    }
    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }
    

}
