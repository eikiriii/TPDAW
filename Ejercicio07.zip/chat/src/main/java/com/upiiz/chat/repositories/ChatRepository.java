package com.upiiz.chat.repositories;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.upiiz.chat.models.ChatModel;

@Repository
public interface ChatRepository {
     public List<ChatModel> findAllChats();
    public ChatModel save(ChatModel model);
}
