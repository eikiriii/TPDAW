package com.upiiz.chat.services;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Service;

import com.upiiz.chat.models.ChatModel;
import com.upiiz.chat.repositories.ChatRepository;

@Service
public class ChatService implements ChatRepository {

    @Autowired
    JdbcTemplate jdbcTemplate;

    @Override
    public List<ChatModel> findAllChats() {
        return jdbcTemplate.query("SELECT * FROM conversacion",
                new BeanPropertyRowMapper<>(ChatModel.class));
    }

    @Override
    public ChatModel save(ChatModel chat) {
        KeyHolder keyHolder = new GeneratedKeyHolder(); // Para capturar el ID generado

        jdbcTemplate.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(
                    "INSERT INTO conversacion(mensaje) VALUES (?)",
                    Statement.RETURN_GENERATED_KEYS // Indicar que queremos recuperar las claves generadas
            );
            ps.setString(1, chat.getMensaje());
            return ps;
        }, keyHolder);
        

        // Obtenemos el ID generado y lo asignamos al producto
        Number generatedId = keyHolder.getKey();
        if (generatedId != null) {
            chat.setId(generatedId.intValue());
        }else {
            chat.setId(0);
        }

        return chat; // Retornamos el modelo con el ID asignado

}
}

